<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>fristAssignment.com</title>

<style>

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #018DD9;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.data{
	margin-top:3%;
	
	margin-right:45px;
	margin-left:45px;
	padding:15px 20px 25px ;

}
.data h2
{
padding-left:20%;	
}

</style>
</head>
<body>

<div class="data">
<h2>Semester Admission Form For Students</h2>
<form action="save.php" method="POST" name="reg" enctype="multipart/form-data">

<p>
<br>
Department:<select name="department">
<option>BS(CS)</option>
<option>BS(EE)</option>
<option>BBA</option>
</select><br>
<br>

Name:<input type="text" name="name" maxlength="30"  pattern="[A-Z a-z]{1,30}" required> <br>
<br>    
Candidate's CNIC:<input type="text" name="cnic" maxlength="15" size="15" placeholder="12345-1234567-1" pattern="[0-9]{5}[-][0-9]{7}[-][0-9]{1}" > <br>
<br>    
Gender:    <input type="radio" name="gender" value="male"/> Male
 <input type="radio" name="gender" value="female"/> Female <br>
<br>
<div class="font-skills">
<br><br>
<b>Courses you want to study:</b>
<input  type="checkbox" value="Java" name="techno[]" /> Java
<input  type="checkbox" value="C++" name="techno[]" /> C++
<input  type="checkbox" value="C" name="techno[]" /> C 
<input  type="checkbox" value="Python" name="techno[]" /> Python
<input  type="checkbox" value="PHP" name="techno[]" /> PHP
<input  type="checkbox" value="MySQL" name="techno[]"  /> MySQL
<input  type="checkbox" value="C#" name="techno[]" /> C# <br> <br> 
</div>
<br><br>
<label for="img">Select image:</label>
<input type="file" id="image" name="image" accept="image/*">
<br><br>
</p> 
<input style="margin-left:50%;" type="submit" value="submit" name="submit">               
</div>
</form>
</body>
</html>