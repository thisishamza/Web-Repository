<?php
session_start();
include "index.php";
$conn=saveDatabase();
if($conn==TRUE)
{
	echo "<br>Database connected<br>";
}
else
{
	echo "<br>db not connected<br>";
}
if(isset($_POST['submit'])){
	$_SESSION['dep']=$_POST['department']; 
	$_SESSION['n']=$_POST['name']; 
	$_SESSION['c']=$_POST['cnic']; 
$department=$_POST['department'];    
$gender = $_POST['gender'];
$name  = $_POST['name'];
$cnic = $_POST['cnic'];
$checkbox1=$_POST['techno'];  
$chk="";
foreach($checkbox1 as $chk1)  
   {  
      $chk .= $chk1.",";  
   }
	if(isset($_FILES['image'])){
		$image = $_FILES['image']['name'];
	}
	$target = "img/".basename($image);
}	  
	 
	  $sql="insert into data(department,name,cnic,gender,course,image) 
     values('$department','$name','$cnic','$gender','$chk','$image')";
$result=mysqli_query($conn,$sql);

if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
	$msg = "Image uploaded successfully";
}else{
	$msg = "Failed to upload image";
}
if($result)
{
 echo "<br>data inserted<br>";
print_r($_SESSION);
 
} 
else
{
echo "<br>failed<br>";
echo "<h3>Error:</h3>$conn->error()";
}
closeCon($conn);
?>